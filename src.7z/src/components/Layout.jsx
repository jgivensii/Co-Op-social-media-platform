import React, { Component } from 'react';
////import { Container } from 'reactstrap';
import { NavMenu } from './NavMenu';
import { LeftBar } from './Leftbar/LeftBar';
import { RightBar } from './Rightbar/RightBar';
import MaybeShowNavBar from '../MaybeShowNavBar';


export class Layout extends Component {
  static displayName = Layout.name;

  render() {
    return (
      <div>
        
        <MaybeShowNavBar>
        <NavMenu />
        </MaybeShowNavBar>
          <div style={{display:"flex"}}>
          <MaybeShowNavBar>
          <LeftBar/>
          </MaybeShowNavBar>
          
          {this.props.children}
          
          <MaybeShowNavBar>
          <RightBar/>
          </MaybeShowNavBar>
          </div>
         
        
      </div>
    );
  }
}
