import React, { Component } from 'react';
import './scss files/home.scss'
import { Story } from './stories/Story';
import { Posts } from './posts/Posts';
//import { Posts } from './posts/Posts';
 

export class Home extends Component {
  static displayName = Home.name;

  render() {
    return (
      <div className="home2" >
           <Story/>
           <Posts/>
           <h1>Empty Posts</h1>
           <h1>Empty Posts</h1>
           <h1>Empty Posts</h1>
           <h1>Empty Posts</h1>
           <h1>Empty Posts</h1>
           <h1>Empty Posts</h1>
           <h1>Empty Posts</h1>
           <h1>Empty Posts</h1>
           <h1>Empty Posts</h1>
           <h1>Empty Posts</h1>
           <h1>Empty Posts</h1>
           <h1>Empty Posts</h1>
           <h1>Empty Posts</h1>
           <h1>Empty Posts</h1>
           <h1>Empty Posts</h1>
           <h1>Empty Posts</h1>
           <h1>Empty Posts</h1>
           <h1>Empty Posts</h1>
           
    </div>
    );
  }
}
