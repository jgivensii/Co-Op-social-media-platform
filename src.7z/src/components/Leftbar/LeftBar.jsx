import React, { Component } from 'react';
import './leftbar.scss';
import { FcCalendar, FcCollaboration, FcConferenceCall, FcFilm, FcGallery, FcShop, FcSupport } from "react-icons/fc";
import { GoPerson } from 'react-icons/go';
import {GiConsoleController} from 'react-icons/gi';
import { Navbar, NavbarBrand } from 'reactstrap';
import { Link } from 'react-router-dom';


export class LeftBar extends Component {
  static displayName = LeftBar.name;

  render() {
    return (
      
        <div className="leftbar2">
          <Navbar>
          <div className='container2'>
            <div className='menu2'>
            
              <div className='user2'>
              <NavbarBrand tag={Link} to="/profile"><div className='item2'><div className='icon2'><div className='user'><GoPerson className="NoProPic"/></div></div><span>Me</span></div></NavbarBrand>
              <div className='item2'><div className='icon2'><FcCollaboration size={32}/></div><span>Friends</span></div>
             <div className='item2'><div className='icon2'><FcConferenceCall size={32}/></div><span>Gaming Groups</span> </div>
                </div>
              <hr/>
              <div className='apps2'>
              <span>Apps</span>
              
             
             <div className='item2'><div className='icon2'><FcFilm size={32}/></div><span>Videos</span></div>
             <div className='item2'><div className='icon2'><FcGallery size={32}/></div><span>Photos</span></div>
             <div className='item2'><div className='icon2'><GiConsoleController size={32}/></div><span>Gaming Streams</span></div>
             <div className='item2'><div className='icon2'><FcShop size={32}/></div><span>Marketplace</span></div>
             <div className='item2'><div className='icon2'><FcCalendar size={32}/></div><span>Calendar</span></div>
             
            

             </div>
            
             <hr/>
             <div className="others2">
              
             <div className='item2'><div className='icon2'><FcSupport size={32}/></div><span>Settings</span></div>
             </div>
            </div>
          </div>
          </Navbar>
        </div>
        
    );
  }
} 