
import React, { useState } from 'react';
import './Registration.scss';
import { Link } from 'react-router-dom';
import axios from 'axios';


function Registration(){
  
    const [ firstname, setFirstName] = useState('');
    const [ lastname, setLastName] = useState('');
    const [ email, setEmail] = useState('');
    const [ password, setPassword] = useState(''); 
    const [ username, setUserName] = useState('');


    

    const handleSave = (e) => {
    
        e.preventDefault();
        
        const url = `/registration`;

        const data = { 
        FirstName: firstname,
        LastName: lastname,
        Email: email,
        UserName: username,
        Password: password
    }
    console.log(firstname,lastname,email,username,password);
    axios.post(url, data, {headers: {'Accept': 'application/json',
    'Content-Type': 'application/json','Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': '*', }}
        //the token is a variable which holds the token
      )
    .then((result)=> {
        alert(result.data);
    }) 
    .catch((error)=>{
        console.log(error)
    })  
    }
    return (
        <div className="register">
        <div className="card2">
            <div className="left">
                <h1>Plug in!</h1>
                <p>
                    Register and take the first step in joining a new gaming world!
                </p>
                <span>Already have an Account?</span>
               <Link to="/login"> <button>Login</button></Link>
            </div>
            <div className="right">
                <h1>Register</h1>
                <form>
                    <input type="text" placeholder="First Name" onChange={(e)=> setFirstName(e.target.value)}/>
                    <input type="text" placeholder="Last Name" onChange={(e)=> setLastName(e.target.value)}/>
                    <input type="email" placeholder="Email Address" onChange={(e)=> setEmail(e.target.value)}/>
                    <input type="text" placeholder="Username" onChange={(e)=> setUserName(e.target.value)}/>
                    <input type="password" placeholder="Password" onChange={(e)=> setPassword(e.target.value)}/>
                    <input type="password" placeholder="Confirm Password" />
                    <button onClick={(e)=> handleSave(e)}>Register</button>
                </form>
                
            </div>
        </div>

    </div>
    );
  };


export default Registration;