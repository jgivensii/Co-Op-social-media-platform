import React, { Component } from 'react';
import { Collapse, Nav, Navbar, NavbarBrand, NavbarToggler, } from 'reactstrap';
import { Link } from 'react-router-dom';
import './NavMenu.scss';
import { GoHome, GoStack, GoMail, GoBell, GoSearch, GoPerson } from "react-icons/go";
export class NavMenu extends Component {
  static displayName = NavMenu.name;

  constructor (props) {
    super(props);

    this.toggleNavbar = this.toggleNavbar.bind(this);
    this.state = {
      collapsed: true
    };
  }

  toggleNavbar () {
    this.setState({
      collapsed: !this.state.collapsed
    });
  }

  render() {
    return (
      <header>
        
        <Navbar className="navbar-expand-sm navbar-toggleable-sm ng-white border-bottom fixed-top" vertical container color="white"  >
          <NavbarBrand tag={Link} to="/">CoOp</NavbarBrand>
          <NavbarBrand tag={Link} to="/"><GoHome/></NavbarBrand>
          <NavbarBrand tag={Link} to="/"><GoStack/></NavbarBrand>
          <div className='search'>
          <GoSearch/>
          <input type="text" placeholder='Search...'/>
          </div>
          <NavbarToggler onClick={this.toggleNavbar} className="mr-2" /> 
           
          <Collapse className="flex-column flex-sm-row-reverse" isOpen={!this.state.collapsed} navbar>
            <Nav navbar>
              <NavbarBrand tag={Link} to="/"><GoBell/></NavbarBrand>
              <NavbarBrand tag={Link} to="/"><GoMail/></NavbarBrand>
              <NavbarBrand tag={Link} to="/profile"><div className='user'><GoPerson className="NoProPic"/></div></NavbarBrand>
            </Nav>
              
            
            
          </Collapse>
        </Navbar>
       
      </header>
    );
  }
}
