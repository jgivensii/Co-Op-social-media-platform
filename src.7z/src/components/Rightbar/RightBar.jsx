import React, { Component } from 'react';
import './rightbar.scss';

export class RightBar extends Component {
  static displayName = RightBar.name;

  render() {
    return (
        <div className="rightbar2">
          <div className='container'>
            <div className="item">
              <span>New Friend Suggestions</span>
              <div className="user">
                <div className="userinfo">

                </div>
              </div>
            </div>
            <div className="item">
              <span>Latest Activities</span>
              <div className="user">
                <div className="userinfo">

                </div>
              </div>
            </div>
            <div className="item">
              <span>Online Friends</span>
              <div className="user">
                <div className="userinfo">

                </div>
              </div>
              
               
            </div>
          </div>
    </div>
    );
  }
} 