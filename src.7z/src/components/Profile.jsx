import React, { Component } from 'react';
import './scss files/home.scss';


export class Profile extends Component {
  static displayName = Profile.name;

  render() {
    return (
      <div className="home2" >
           <h1>Profile Page goes here</h1>
           
    </div>
    );
  }
}