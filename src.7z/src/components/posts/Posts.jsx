import React, { Component } from 'react';
import './Posts.scss';
import { GoDeviceCameraVideo, GoFileDirectory, GoFileMedia, GoPerson, GoRocket } from 'react-icons/go';
import { Link } from 'react-router-dom';

 

export class Posts extends Component {
  static displayName = Posts.name;

  render() {
    return (
      <div className="Posts">
            <div className="post">
                <div className='user2'>
                    <Link className="link2" to='/profile'><GoPerson className="NoProPic2" /></Link>
                    <input type="text" placeholder='Share your Thoughts!'/>
                </div>
                <div className="tabs">
             <span><GoFileMedia/>Photo</span>
             <span><GoDeviceCameraVideo/>Video</span>
             <span><GoFileDirectory/>File</span>
             <span><GoRocket/>Post</span>
                

            </div>
            </div>
            

      </div>
    );
  }
}