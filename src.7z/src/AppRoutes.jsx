
///import ProtectedView from "./ProtectedView";
import { Home } from "./components/Home";





const AppRoutes = [
  {
    path:"/",
    element: < Home/>
  }
  
  
];

export default AppRoutes;
