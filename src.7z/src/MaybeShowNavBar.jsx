import React, {useEffect, useState} from 'react';
import {useLocation} from 'react-router-dom';

const MaybeShowNavBar =({children}) => {

    const location = useLocation();

    const[ShowNavBar, setShowNavBar] = useState(false)

    useEffect(() => {
        if(location.pathname==='/login/' || location.pathname==='/register/'|| location.pathname==='/register/*' || location.pathname==='/register' || location.pathname==='/login/*' || location.pathname==='/login') 
        {
            setShowNavBar(false)
        }
            else 
            {
                setShowNavBar(true)
            }
        }, [location])

        return(
            <div>{ShowNavBar && children}</div>
        )
}

export default MaybeShowNavBar